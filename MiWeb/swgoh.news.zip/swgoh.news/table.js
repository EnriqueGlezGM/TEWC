$(document).ready( function () {
    $('#table_id').dataTable();
} );