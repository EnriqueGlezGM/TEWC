<!DOCTYPE html>
<!---Enrique Gonzalez Macias-->
<html xmlns="http://www.w3.org/1999/html">
<head>
    <title>Result</title>
    <meta charset="UTF-8">
    <script src="https://kit.fontawesome.com/9a476323d1.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="assets/css/table.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.css">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico"/>
</head>

<body>

<i class="fas fa-arrow-left" onclick="history.back(-1)"></i>
<div class="background">
    <div class="container">
        <div class="panel">

            <div class="table">
                <table id="table_id" class="display">
                    <thead>
                    <tr>
                        <th>News</th>
                        <th>Type</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>Tech</td>
                        <td>Character</td>
                    </tr>
                    <tr>
                        <td>Hunter</td>
                        <td>Character</td>
                    </tr>
                    <tr>
                        <td>Minor changes</td>
                        <td>Update</td>
                    </tr>
                    <tr>
                        <td>Stats from March</td>
                        <td>META</td>
                    </tr>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>

<script src="//code.jquery.com/jquery-2.1.3.min.js"></script>
<script src="//cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script src="table.js"></script>
</body>


</html>