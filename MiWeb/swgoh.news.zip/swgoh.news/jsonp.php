<?php
require_once 'conectar.php';

$sql = "SELECT type, year, info, image FROM news LIMIT 6";
$statement = $db->prepare($sql);
$statement->execute();

while ($fila = $statement->fetch()) {
	$filas[] = array(
			"type" => $fila['type'],
			"year" => $fila['year'],
			"info" => $fila['info'],
			"image" => $fila['image']);
}

$json = json_encode($filas); 
$callback = $_GET['callback'];
echo $callback.'('. $json . ')';
?>

