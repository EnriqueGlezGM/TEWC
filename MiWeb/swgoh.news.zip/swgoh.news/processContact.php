<?php
define("RECIPIENT_NAME", "TEWC");
define("RECIPIENT_ADDRESS", "prueba@gmail.com");
define("EMAIL_SUBJETC", "Formulario PHP");


$email = $_REQUEST['email'];
$message = $_REQUEST['message'];
$success = false;

if (!empty($email) && !empty($message)) {
    $recipient = RECIPIENT_NAME . " <" . RECIPIENT_ADDRESS . ">";
    $headers = "From: " . $message . "<" . $email . ">";
    $success = mail($recipient, EMAIL_SUBJETC, $message, $headers);
}
?>

<!DOCTYPE html>
<html class="no-js" lang="">
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="x-ua-compatible" content="ie=edge"/>
    <title>SWGOH.NEWS</title>
    <meta name="description" content=""/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico"/>
    <script src="https://kit.fontawesome.com/9a476323d1.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="assets/css/bootstrap-5.0.0-alpha-2.min.css"/>
    <link rel="stylesheet" href="assets/css/LineIcons.2.0.css"/>
    <link rel="stylesheet" href="assets/css/animate.css"/>
    <link rel="stylesheet" href="assets/css/main.css"/>
</head>
<body>
<section id="home" class="hero-section">
    <i class="fas fa-arrow-left" onclick="history.back(-1)"></i>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 col-xl-7">
                <div class="hero-content">
                    <p class="wow fadeInUp" data-wow-delay=".4s">Your email: <?php echo "{$email}"; ?> </p>
                    <p class="wow fadeInUp" data-wow-delay=".4s">Your message: <?php echo "{$message}"; ?></p>
                    <?php
                    if ($success):
                        ?>
                        <h1 class="wow fadeInUp" data-wow-delay=".2s">Successfully send it!</h1>
                    <?php
                    else:
                        ?>
                        <h1 class="wow fadeInUp" data-wow-delay=".2s">Error, try again</h1>
                    <?php
                    endif
                    ?>
                </div>
            </div>
        </div>
    </div>
</section>
</body>
</html>


