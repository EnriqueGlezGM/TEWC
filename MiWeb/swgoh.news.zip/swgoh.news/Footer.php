<div class="container">
    <div class="subscribe-wrapper">
        <div class="row justify-content-center">
            <div class="col-xl-6 col-lg-9">
                <div class="section-title text-center mb-45">
                    <h1 class="mb-25 text-white wow fadeInUp" data-wow-delay=".2s">Subscribe Our Newsletter</h1>
                    <!--<p class="text-white wow fadeInUp" data-wow-delay=".4s">Lorem ipsum dolor sit amet, consetetur
                        sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore</p>-->
                </div>
                <form action="#" class="subscribe-form wow fadeInUp" data-wow-delay=".6s">
                    <input type="email" name="subs-email" id="subs-email" placeholder="Your email">
                    <button type="submit" class="main-btn btn-hover">Subscribe Now</button>
                </form>
            </div>
        </div>
    </div>
    <div class="widget-wrapper">
        <div class="row">
            <div class="col-lg-3 col-sm-6">
                <div class="footer-widget">
                    <div class="logo">
                        <a href="https://www.instagram.com/swgoh.news/" rel="nofollow"> <img src="assets/img/logo/IG.png" alt="logo"> </a>
                    </div>

                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="footer-widget">
                    <h3 class="text-white">Explore</h3>
                    <ul class="links">
                        <li>
                            <a href="javascript:void(0)">About </a>
                        </li>
                        <li>
                            <a href="javascript:void(0)">Our Team </a>
                        </li>
                        <li>
                            <a href="javascript:void(0)">Features </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="footer-widget">
                    <h3 class="text-white">Terms</h3>
                    <ul class="links">
                        <li>
                            <a href="javascript:void(0)">Refund Policy</a>
                        </li>
                        <li>
                            <a href="javascript:void(0)">Terms of Service</a>
                        </li>
                        <li>
                            <a href="javascript:void(0)">Support Policy</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="footer-widget">
                    <h3 class="text-white">Links</h3>
                    <ul class="links">
                        <li>
                            <a href="javascript:void(0)">Help </a>
                        </li>
                        <li>
                            <a href="javascript:void(0)">Support </a>
                        </li>
                        <li>
                            <a href="javascript:void(0)">Contact </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
