<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.80.0">
    <title>Starter Template · Bootstrap v5.0</title>
    <link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/starter-template/">
    <!-- Bootstrap core CSS -->
    <link href="https://getbootstrap.com/docs/5.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="https://getbootstrap.com/docs/5.0/examples/starter-template/starter-template.css" rel="stylesheet">
</head>
<body>

<main class="container">

    <h1 class="text-center">Secuecia de Fibonacci</h1>

    <table class="table table-striped">
        <thead>
        <tr>
            <th scope="col">Secuencia #1</th>
            <th scope="col">Valor</th>
        </tr>
        </thead>
        <tbody>
        <?php
            $fibonacci = [0, 1];
            for ($i = 0; $i <= 11; $i++) {
                $fibonacci[] = $fibonacci[$i] + $fibonacci[$i + 1];
                echo " 
                    <tr>
                        <td>F<sub>$i</sub></td>
                        <td>$fibonacci[$i]</td>
                    </tr>
                ";
            }
        ?>
        </tbody>
    </table>

</main><!-- /.container -->

</body>
</html>

