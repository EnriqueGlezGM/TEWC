<h1>
    <?php

    $hora = date("G");
    $año = date("Y");
    $bisiesto="no";

    if ($hora >= 5 && $hora <= 16) {
        echo "<h1>¡Buenos días!</h1>";
    } elseif ($hora >= 16 && $hora <= 21) {
        echo "<h1>¡Buenos tardes!</h1>";
    } else {
        echo "<h1>¡Buenos noches!</h1>";
    }
    if($año-1%4===0){
        $bisiesto="si";
    }
    echo "<h1>¿Sabías que $año $bisiesto es bisiesto?</h1>";
    ?>
