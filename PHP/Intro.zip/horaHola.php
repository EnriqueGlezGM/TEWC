<h1>
    <?php
    $hora = date( "g:i:s a" );
    echo "¡Hola mundo! La hora actual es $hora";
    ?>
</h1>